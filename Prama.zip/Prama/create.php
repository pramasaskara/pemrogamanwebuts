<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $jabatan = $_POST['jabatan'];
    $tahun_gabung = $_POST['tahun_gabung'];
    $tahun_keluar = $_POST['tahun_keluar'];
    $role = $_POST['role'];
    $hero_utama = $_POST['hero_utama'];
    $hero_kedua = $_POST['hero_kedua'];

    $mysqli->query("INSERT INTO players (nama, jabatan, tahun_gabung, tahun_keluar, role, hero_utama, hero_kedua) VALUES ('$nama', '$jabatan', '$tahun_gabung', '$tahun_keluar', '$role', '$hero_utama', '$hero_kedua')");
    
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Pemain</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Tambah Pemain</h1>
        <div class="button-container">
            <a href="index.php">Kembali</a>
        </div>
        <form method="POST">
            <label>Nama: </label>
            <input type="text" name="nama" required>
            
            <label>Jabatan: </label>
            <input type="text" name="jabatan" required>
            
            <label>Tahun Gabung: </label>
            <input type="number" name="tahun_gabung" required>
            
            <label>Tahun Keluar: </label>
            <input type="number" name="tahun_keluar" required>
            
            <label>Role: </label>
            <input type="text" name="role" required>
            
            <label>Hero Utama: </label>
            <input type="text" name="hero_utama" required>
            
            <label>Hero Kedua: </label>
            <input type="text" name="hero_kedua" required>
            
            <button type="submit">Simpan</button>
        </form>
    </div>
</body>
</html>
