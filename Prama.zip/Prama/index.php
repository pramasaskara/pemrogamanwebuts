<?php
include 'config.php';

$result = $mysqli->query("SELECT * FROM players");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Pemain</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Data Pemain</h1>
        <div class="button-container">
            <a href="create.php">Tambah Data</a>
        </div>
        <table>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Jabatan</th>
                <th>Tahun Gabung</th>
                <th>Tahun Keluar</th>
                <th>Role</th>
                <th>Hero Utama</th>
                <th>Hero Kedua</th>
                <th>Aksi</th>
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['nama']; ?></td>
                <td><?php echo $row['jabatan']; ?></td>
                <td><?php echo $row['tahun_gabung']; ?></td>
                <td><?php echo $row['tahun_keluar']; ?></td>
                <td><?php echo $row['ROLE']; ?></td>
                <td><?php echo $row['hero_utama']; ?></td>
                <td><?php echo $row['hero_kedua']; ?></td>
                <td>
                    <a href="show.php?id=<?php echo $row['id']; ?>">Lihat</a>
                    <a href="edit.php?id=<?php echo $row['id']; ?>">Edit</a>
                    <a href="delete.php?id=<?php echo $row['id']; ?>" onclick="return confirm('Anda yakin ingin menghapus data ini?')">Hapus</a>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>
