<?php
include 'config.php';

$id = $_GET['id'];
$mysqli->query("DELETE FROM players WHERE id = $id");

header("Location: index.php");
exit;
?>
