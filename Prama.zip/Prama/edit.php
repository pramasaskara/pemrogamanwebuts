<?php
include 'config.php';

$id = $_GET['id'];
$result = $mysqli->query("SELECT * FROM players WHERE id = $id");
$row = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $jabatan = $_POST['jabatan'];
    $tahun_gabung = $_POST['tahun_gabung'];
    $tahun_keluar = $_POST['tahun_keluar'];
    $role = $_POST['ROLE'];
    $hero_utama = $_POST['hero_utama'];
    $hero_kedua = $_POST['hero_kedua'];

    $mysqli->query("UPDATE players SET nama='$nama', jabatan='$jabatan', tahun_gabung='$tahun_gabung', tahun_keluar='$tahun_keluar', role='$role', hero_utama='$hero_utama', hero_kedua='$hero_kedua' WHERE id = $id");
    
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Pemain</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Edit Pemain</h1>
        <div class="button-container">
            <a href="index.php">Kembali</a>
        </div>
        <form method="POST">
            <label>Nama: </label>
            <input type="text" name="nama" value="<?php echo $row['nama']; ?>" required>
            
            <label>Jabatan: </label>
            <input type="text" name="jabatan" value="<?php echo $row['jabatan']; ?>" required>
            
            <label>Tahun Gabung: </label>
            <input type="number" name="tahun_gabung" value="<?php echo $row['tahun_gabung']; ?>" required>
            
            <label>Tahun Keluar: </label>
            <input type="number" name="tahun_keluar" value="<?php echo $row['tahun_keluar']; ?>" required>
            
            <label>Role: </label>
            <input type="text" name="role" value="<?php echo $row['ROLE']; ?>" required>
            
            <label>Hero Utama: </label>
            <input type="text" name="hero_utama" value="<?php echo $row['hero_utama']; ?>" required>
            
            <label>Hero Kedua: </label>
            <input type="text" name="hero_kedua" value="<?php echo $row['hero_kedua']; ?>" required>
            
            <button type="submit">Update</button>
        </form>
    </div>
</body>
</html>
